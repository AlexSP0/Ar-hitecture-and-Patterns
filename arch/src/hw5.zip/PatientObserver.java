public interface PatientObserver {
    void update(int age);

}
